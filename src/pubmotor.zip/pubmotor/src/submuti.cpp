#include "ros/ros.h"
#include "std_msgs/String.h"
#include <can_msgs/Frame.h>
#include <boost/thread.hpp>
#include "pubmotor/motor.h"
class multiThreadListener
{
public:
	multiThreadListener()
	{
    pub = nh.advertise<pubmotor::motor>("motor_message",10);
    sub = n.subscribe("motor_message", 1, &multiThreadListener::chatterCallback1,this);
		sub2 = n.subscribe("motor_message", 1, &multiThreadListener::chatterCallback2,this);
    can1 = n.subscribe("received_messages", 1, &multiThreadListener::chatterCallback3,this);
    pubmotor::motor motor_msg;
    motor_msg.id = "motor_001";
    motor_msg.velocity = 0.5;
    motor_msg.acceleration = 0.5;
	}
	void chatterCallback1( const pubmotor::motor::ConstPtr& msg);
	void chatterCallback2( const pubmotor::motor::ConstPtr& msg);
  void chatterCallback3(const can_msgs::Frame::ConstPtr &msg);
  
private:
  // ros::Publisher pub;
	ros::NodeHandle n;
	ros::Subscriber sub;
	ros::Subscriber sub2;
  ros::Subscriber can1;

  
  
  
};

void multiThreadListener::chatterCallback1(const pubmotor::motor::ConstPtr& msg)
{
  ROS_INFO("id: [%s]", msg->id.c_str());
  
}

void multiThreadListener::chatterCallback2(const pubmotor::motor::ConstPtr& msg)
{
  ROS_INFO("id: [%s]", msg->id.c_str());

}
void multiThreadListener::chatterCallback3(const can_msgs::Frame::ConstPtr &msg)
{
      static int times = 0;
	std::cout << times++ << "ID: " << msg->id << " data: " ;    
    for (int i = 0; i < msg->dlc; i++)
    {
        printf("%X ", msg->data[i]);
    }
    std::cout << std::endl;

}
  
int main(int argc, char **argv)
{
  ros::init(argc, argv, "multi_sub");

  multiThreadListener listener_obj;
  
  // spinner.start();
  // ros::MultiThreadedSpinner spinner(2); // Use 4 threads
  // spinner.spin(); 
  ros::AsyncSpinner spinner(3); // Use 2 threads
  spinner.start();
  while (ros::ok())
  {
  
  ros::waitForShutdown();
  }
  
  ROS_INFO("xunhuan");  

  return 0;
}